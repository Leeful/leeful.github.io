Instructions:
----------------------------------------------------------------------------------------------------------
1. Flash the PS-Phive! ESP32-S2 bin file to your ESP32-S2 device using NodeMCU PyFlasher.

2. Install the PS-Phive! menu on your PS4 by either using the PC SelfHost files or the online host URL.

3. When the PS-Phive! menu has finished installing on your PS4, plug in your ESP32-S2 and setup a new
   Internet connection on your PS4: Use Wi-Fi > Easy > PS-Phive! > password: 12345678

4. After the Set Up Internet Connection is complete press back and go to View Connection Status 
   and make sure that it has connected and you have an IP address.


All Done. You can now go back to the browser and use the PS-Phive! menu.

----------------------------------------------------------------------------------------------------------


Links:
----------------------------------------------------------------------------------------------------------
NodeMCU PyFlasher:
 https://github.com/marcelstoer/nodemcu-pyflasher/releases/download/v5.0.0/NodeMCU-PyFlasher.exe

PS-Phive! v2 Online Host:
 http://prb123.ir/ps-phive/v2/index.html

PS-Phive! v2 PC SelfHost Files:
 http://prb123.ir/ps-phive/PS-Phive!_v2_PC_SelfHost_Files.zip

----------------------------------------------------------------------------------------------------------



NOTES:
----------------------------------------------------------------------------------------------------------
**If v2 is not the latest version anymore, the latest version of PS-Phive will be accessible at: 
  prb123.ir/ps-phive (This address will redirect you to the latest version).


**You can change the settings of the PS-Phive! ESP32-S2 bin by going to 10.1.1.1/config.html once you 
  are connected to it on either the PS4 or on a PC.

----------------------------------------------------------------------------------------------------------



PS-Phive! ESP32-S2 bin ChangeLog:
----------------------------------------------------------------------------------------------------------
v2.0:
 Added the option to put your ESP32-S2 into sleep mode after a certain amount of time.(default=20 minutes)
 You can change this time or turn off the feature from the config page.(10.1.1.1/config.html)

 If you connect your ESP32-S2 to your home WiFi network you can see what the IP address of it is next to 
 the WiFi Connection heading section of the config page.

v1.0:
 Initial release.

----------------------------------------------------------------------------------------------------------



----------------------------------------------------------------------------------------------------------
Credit to stooged for the original ESP32-Server-900u sketch and to PRB for his help modifying it.
----------------------------------------------------------------------------------------------------------

